import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';

function DoctorDetails() {
    const[doctor,setDoctor]=useState({});
    // const params=useParams();
    const {id}=useParams();

    const navigate=useNavigate();

   async function getData(){
        let res=await axios.get(`http://localhost:3000/doctors/${id}`);
        console.log(res)
        setDoctor(res.data);
   } 

   async function deleteDoctor(){
        try{
           await axios.delete(`http://localhost:3000/doctors/${id}`)
            alert("deleted!!")
            navigate(-1);

        }
        catch(err){
            console.log(err.response.data.error);
            alert(err.response.data.error);
        }
   }

   useEffect(()=>{
    getData();
   },[])
  return (
    <div>
        <h1>Doctor Details</h1>
        <h2>{doctor.name}</h2>
        <h6>{doctor.specialization}</h6>
        <h6>{doctor.gender}</h6>
        <h6>{doctor.age}</h6>
        <h6>{doctor.salary}</h6>
        <button onClick={deleteDoctor}>Delete</button>
        <button onClick={()=>{
            navigate(`/edit/${id}`)
        }}>
            Edit
        </button>
    </div>
  )
}

export default DoctorDetails